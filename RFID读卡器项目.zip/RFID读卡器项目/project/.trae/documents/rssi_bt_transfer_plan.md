# RFID UHF读卡器蓝牙传输实现计划

## 需求分析

用户需要基于STM32F103C8T6实现：
1. 通过USART1连接RFID UHF读卡器（波特率9600）
2. 通过USART2连接HC-06蓝牙模块（波特率9600）
3. 将读取到的RFID标签数据通过蓝牙传输到串口调试助手
4. 使用STlink下载程序

## 当前代码状态

| 组件 | 当前配置 | 需要修改 |
|------|---------|---------|
| USART1 | 115200波特率，连接RFID | 改为9600波特率 |
| USART2 | 未初始化 | 初始化9600波特率用于HC-06 |
| 标签数据处理 | 只通过RTT打印 | 添加蓝牙发送功能 |

## 修改方案

### 1. 修改文件列表

| 文件 | 修改内容 |
|------|---------|
| `magicrf.c` | 修改USART1初始化波特率为9600 |
| `magicrf.c` | 添加USART2初始化和蓝牙发送函数 |
| `magicrf.c` | 修改标签解析部分，添加蓝牙转发 |
| `magicrf.h` | 添加USART2初始化函数声明 |

### 2. 具体修改步骤

#### 步骤1：修改USART1波特率

在 `magicrf.c` 的 `MagicRFInit()` 函数中：
- 将 `Usart1Init(115200)` 改为 `Usart1Init(9600)`

#### 步骤2：初始化USART2

在 `magicrf.c` 中添加：
```c
void Usart2InitForBT(void)
{
    Usart2Init(9600);  // HC-06默认波特率9600
}
```

在 `magicrf.h` 中添加声明：
```c
void Usart2InitForBT(void);
```

#### 步骤3：添加蓝牙发送函数

在 `magicrf.c` 中添加：
```c
void SendTagViaBluetooth(Tag_Type *tag, uint8_t epclen)
{
    // 格式化输出：RSSI | Ant | PC | EPC
    UsartSendString(USART2, (uint8_t*)"\r\n[RFID] ", 8);
    
    // RSSI
    char tmp[16] = {0};
    sprintf(tmp, "RSSI:%d ", tag->rssi);
    UsartSendString(USART2, (uint8_t*)tmp, strlen(tmp));
    
    // Antenna
    sprintf(tmp, "Ant:%d ", tag->ant);
    UsartSendString(USART2, (uint8_t*)tmp, strlen(tmp));
    
    // PC + EPC
    sprintf(tmp, "PC:%02X%02X EPC:", tag->pc[0], tag->pc[1]);
    UsartSendString(USART2, (uint8_t*)tmp, strlen(tmp));
    
    for(uint8_t i = 0; i < epclen; i++)
    {
        sprintf(tmp, "%02X", tag->epc[i]);
        UsartSendString(USART2, (uint8_t*)tmp, 2);
    }
    
    UsartSendString(USART2, (uint8_t*)"\r\n", 2);
}
```

#### 步骤4：修改标签解析逻辑

在 `MagicRFTest()` 的标签解析部分，添加蓝牙发送调用：
```c
// 解析完成后发送到蓝牙
SendTagViaBluetooth(&tag_t, epclen);
```

#### 步骤5：在main.c中初始化USART2

在 `main()` 函数中，`MagicRFInit()` 之前添加：
```c
Usart2InitForBT();  // 初始化蓝牙串口
```

### 3. 硬件连接图

#### STM32F103C8T6最小系统板引脚

```
STM32F103C8T6
┌─────────────────────────────┐
│ PA0-PA15                    │
│ PB0-PB15                    │
│                             │
│ PA9  (USART1_TX) ──→ RFID_RX │
│ PA10 (USART1_RX) ──→ RFID_TX │
│ PA7  (GPIO_OUT)  ──→ RFID_EN │
│                             │
│ PA2  (USART2_TX) ──→ HC-06_RX│
│ PA3  (USART2_RX) ──→ HC-06_TX│
│                             │
│ 3.3V ──→ RFID VCC, HC-06 VCC │
│ GND  ──→ RFID GND, HC-06 GND │
└─────────────────────────────┘
```

#### 详细连接表

| STM32引脚 | 连接对象 | 功能 |
|-----------|---------|------|
| PA9 | RFID模块RX | USART1发送 |
| PA10 | RFID模块TX | USART1接收 |
| PA7 | RFID模块EN | 读卡器使能 |
| PA2 | HC-06模块RX | USART2发送 |
| PA3 | HC-06模块TX | USART2接收 |
| 3.3V | RFID VCC | 电源 |
| 3.3V | HC-06 VCC | 电源 |
| GND | RFID GND | 地 |
| GND | HC-06 GND | 地 |

#### STlink下载连接

| STlink引脚 | STM32引脚 |
|------------|-----------|
| SWDIO | PA13 |
| SWCLK | PA14 |
| GND | GND |
| 3.3V | 3.3V (可选) |

### 4. 注意事项

1. **HC-06蓝牙模块**：
   - 默认波特率9600，无需修改
   - 连接手机蓝牙后，使用串口调试助手APP连接
   - 模块KEY引脚可悬空（默认从机模式）

2. **RFID读卡器模块**：
   - 确认模块支持9600波特率通信
   - EN引脚为高电平使能

3. **供电**：
   - 建议使用外部3.3V电源或USB转TTL模块供电
   - STlink提供的3.3V电流有限，可能不够驱动两个模块

4. **串口调试助手设置**：
   - 波特率：9600
   - 数据位：8
   - 停止位：1
   - 校验位：无

### 5. 预期输出格式

蓝牙传输的数据格式：
```
[RFID] RSSI:-58 Ant:1 PC:3000 EPC:300834112233445566778899
[RFID] RSSI:-62 Ant:1 PC:3000 EPC:3008AABBCCDDEEFF11223344
```

## 风险处理

1. **波特率不匹配**：确认RFID读卡器波特率确实为9600，否则需要调整
2. **蓝牙连接失败**：检查HC-06模块是否进入配对模式，手机是否正确连接
3. **数据乱码**：检查串口接线是否正确（TX-RX交叉连接）
4. **电源不足**：使用独立电源为模块供电，避免STlink供电不足