#include "main.h"

#include "iwdg.h"
#include "magicrf.h"


// �Ż��ȼ� -o1 �����ʱ�����붨��Ϊ volatile 
volatile System_Type system_t = {0}; 





/**
  * @author    b_q 
  * @date      2018/5/10
  * @brief     ϵͳ�δ�ʱ��
  * @param     
  * @retval    
  * @attention 
  */
void SystickInit(uint32_t freq)
{
    RCC_ClocksTypeDef rcc_clock; 
    RCC_GetClocksFreq(&rcc_clock); 
    
    SysTick_Config(rcc_clock.HCLK_Frequency / freq); 
} 



/**
  * @author    b_q 
  * @date      2018/5/10
  * @brief     ϵͳ�δ�ʱ��
  * @param     
  * @retval    
  * @attention 
  */
void delay_ms(uint32_t xms)
{ 
    uint32_t tick = system_t.tick + xms; 
    
    FeedDog(); 
    while(system_t.tick < tick) 
    { 
        // ��ʱι��
        if((system_t.tick & 0x3F) == 0)
            FeedDog(); 
    }
}





/**
  * @author    b_q
  * @date      2020/2/21
  * @brief     ���������
  * @param     
  * @retval    
  * @attention 
  */
int main(void) 
{ 
    
    NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2); 
    SystickInit(1000);                                      // ����ϵͳʱ��
    LogInit();                                              // ��ʼ�� RTT ��־��ͨ��jlink���߿ɲ鿴��������
    
    IwdgInit(IWDG_Prescaler_128, 0x64);                     // �������Ź�
    
    Usart2InitForBT();
    
    delay_ms(100);
    UsartSendString(USART2, (uint8_t*)"\r\nRFID Reader Ready!\r\n", 22);
    
    Log("\r\n\n\n %s %s", __DATE__, __TIME__); 
    
    Log("\r\n Checking Reader ... "); 
    UsartSendString(USART2, (uint8_t*)"Checking RFID Reader...\r\n", 23);
    
    if(MagicRFInit() == 0) 
    { 
        Success("Pass"); 
        UsartSendString(USART2, (uint8_t*)"RFID Reader Init OK!\r\n", 21);
    }
    else 
    { 
        Error("Fail"); 
        UsartSendString(USART2, (uint8_t*)"RFID Reader Init FAIL!\r\n", 24);
        UsartSendString(USART2, (uint8_t*)"Check: Baudrate, Wiring, Power\r\n", 33);
    }
    
    
    for( ; ; ) 
    { 
        MagicRFTest(); 
    } 
    
}


