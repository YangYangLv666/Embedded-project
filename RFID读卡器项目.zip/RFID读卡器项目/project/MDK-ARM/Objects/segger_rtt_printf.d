.\objects\segger_rtt_printf.o: ..\SEGGER_RTT_V646a\RTT\SEGGER_RTT_printf.c
.\objects\segger_rtt_printf.o: ..\SEGGER_RTT_V646a\RTT\SEGGER_RTT.h
.\objects\segger_rtt_printf.o: ..\SEGGER_RTT_V646a\RTT\SEGGER_RTT_Conf.h
.\objects\segger_rtt_printf.o: E:\liangxu\keil5\ARM\ARMCC\Bin\..\include\stdlib.h
.\objects\segger_rtt_printf.o: E:\liangxu\keil5\ARM\ARMCC\Bin\..\include\stdarg.h
