#ifndef __SG90_H__
#define __SG90_H__

#include "sys.h"

void sg90_init(void);
void sg90_angle_set(uint16_t angle);
void sg90_turn_left(void);
void sg90_turn_middle(void);
void sg90_turn_right(void);

#endif
