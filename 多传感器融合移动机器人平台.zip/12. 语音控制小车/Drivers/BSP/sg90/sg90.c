#include "sg90.h"


TIM_HandleTypeDef tim3_handle = {0};
// init����
void tim3_init(void)
{
    TIM_OC_InitTypeDef pwm_config = {0};
    
    tim3_handle.Instance = TIM3;
    tim3_handle.Init.Prescaler = 7200 - 1;
    tim3_handle.Init.Period = 200 - 1;
    tim3_handle.Init.CounterMode = TIM_COUNTERMODE_UP;
    HAL_TIM_PWM_Init(&tim3_handle);
    
    pwm_config.OCMode = TIM_OCMODE_PWM1;
    pwm_config.Pulse = 100;
    pwm_config.OCPolarity = TIM_OCPOLARITY_HIGH;
    HAL_TIM_PWM_ConfigChannel(&tim3_handle, &pwm_config, TIM_CHANNEL_1);
    HAL_TIM_PWM_Start(&tim3_handle, TIM_CHANNEL_1);
}


//msp����
void HAL_TIM_PWM_MspInit(TIM_HandleTypeDef *htim)
{
    if(htim->Instance == TIM3)
    {
        GPIO_InitTypeDef gpio_initstruct;
        //��ʱ��
        __HAL_RCC_GPIOA_CLK_ENABLE();                           // ʹ��GPIOBʱ��
        __HAL_RCC_TIM3_CLK_ENABLE();
        
        //����GPIO��ʼ������
        gpio_initstruct.Pin = GPIO_PIN_6;                    // ����LED��Ӧ������
        gpio_initstruct.Mode = GPIO_MODE_AF_PP;             // �������
        gpio_initstruct.Pull = GPIO_PULLUP;                     // ����
        gpio_initstruct.Speed = GPIO_SPEED_FREQ_HIGH;           // ����
        HAL_GPIO_Init(GPIOA, &gpio_initstruct);
    }
}


//�޸�CCRֵ�ĺ���
void tim3_compare_set(uint16_t val)
{
    __HAL_TIM_SET_COMPARE(&tim3_handle, TIM_CHANNEL_1, val);
}

void sg90_init(void)
{
    tim3_init();
}

void sg90_angle_set(uint16_t angle)
{
    uint16_t CCRx = (1.0 / 9.0) * angle + 5.0;
    tim3_compare_set(CCRx);
}

void sg90_turn_left(void)
{
    sg90_angle_set(180);
}

void sg90_turn_middle(void)
{
    sg90_angle_set(90);
}

void sg90_turn_right(void)
{
    sg90_angle_set(0);
}
