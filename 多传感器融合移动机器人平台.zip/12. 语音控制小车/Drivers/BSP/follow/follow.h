#ifndef __FOLLOW_H__
#define __FOLLOW_H__

#include "sys.h"

void follow_init(void);
uint8_t follow_left_flag(void);
uint8_t follow_right_flag(void);

#define     TRUE    1
#define     FALSE   0

#endif
