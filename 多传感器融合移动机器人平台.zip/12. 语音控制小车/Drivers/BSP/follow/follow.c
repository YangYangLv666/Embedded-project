#include "follow.h"
#include "sys.h"
#include "delay.h"
#include "led.h"

//uint8_t ia_flag = FALSE;

void follow_init(void)
{
    GPIO_InitTypeDef gpio_initstruct;
    //��ʱ��
    __HAL_RCC_GPIOB_CLK_ENABLE();                           // ʹ��GPIOAʱ��
    
    //����GPIO��ʼ������
    gpio_initstruct.Pin = GPIO_PIN_5 | GPIO_PIN_6;                       // ������Ӧ������
    gpio_initstruct.Mode = GPIO_MODE_INPUT;            
    gpio_initstruct.Pull = GPIO_PULLUP;                     // ����
    HAL_GPIO_Init(GPIOB, &gpio_initstruct);
    
}

uint8_t follow_left_flag(void)
{
    if(HAL_GPIO_ReadPin(GPIOB, GPIO_PIN_5) == GPIO_PIN_RESET)
        return TRUE;
    else
        return FALSE;
}

uint8_t follow_right_flag(void)
{
    if(HAL_GPIO_ReadPin(GPIOB, GPIO_PIN_6) == GPIO_PIN_RESET)
        return TRUE;
    else
        return FALSE;
}

