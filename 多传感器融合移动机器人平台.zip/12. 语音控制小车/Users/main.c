#include "sys.h"
#include "delay.h"
#include "led.h"
#include "uart1.h"
#include "motor.h"
#include "follow.h"
#include "hcsr04.h"
#include "sg90.h"
#include "track.h"
#include "voice.h"

double dis_left = 0, dis_middle = 0, dis_right = 0;

void track_mode(void)
{
    if(track_left_flag() == TRUE && track_right_flag() == TRUE)
        motor_go_forward();
    else if(track_left_flag() == FALSE && track_right_flag() == TRUE)
        motor_go_left();
    else if(track_left_flag() == TRUE && track_right_flag() == FALSE)
        motor_go_right();
    else if(track_left_flag() == FALSE && track_right_flag() == FALSE)
        motor_stop();
}

void follow_mode(void)
{
    if(follow_left_flag() == TRUE && follow_right_flag() == TRUE)
        motor_go_forward();
    else if(follow_left_flag() == TRUE && follow_right_flag() == FALSE)
        motor_go_left();
    else if(follow_left_flag() == FALSE && follow_right_flag() == TRUE)
        motor_go_right();
    else if(follow_left_flag() == FALSE && follow_right_flag() == FALSE)
        motor_stop();
}

void avoid_mode(void)
{
    dis_middle = hcsr04_get_length();
    if(dis_middle > 35)
        motor_go_forward();
    else if(dis_middle < 15)
        motor_go_backward();
    else
    {
        motor_stop();
        
        //���󿴲�����������
        sg90_turn_left();
        delay_ms(500);
        dis_left = hcsr04_get_length();
        
        //����
        sg90_turn_middle();
        delay_ms(500);
        
        //���ҿ��������Ҳ����
        sg90_turn_right();
        delay_ms(500);
        dis_right = hcsr04_get_length();
        
        //���ݾ����ж���ת������ת
        if(dis_left < dis_right)
            motor_go_right();
        else
            motor_go_left();
        
        delay_ms(200);
        motor_stop();
        sg90_turn_middle();
    }
    delay_ms(100);
}

int main(void)
{
    HAL_Init();                         /* ��ʼ��HAL�� */
    stm32_clock_init(RCC_PLL_MUL9);     /* ����ʱ��, 72Mhz */
    led_init();                         /* ��ʼ��LED�� */
    uart1_init(115200);
    motor_init();
    follow_init();
    hcsr04_init();
    sg90_init();
    track_init();
    voice_init();
    printf("hello world!\r\n");

    sg90_turn_middle();
    while(1)
    { 
//        track_mode();
//        follow_mode();
//        avoid_mode();
        if(TRACK_PIN == GPIO_PIN_RESET && FOLLOW_PIN == GPIO_PIN_SET && AVOID_PIN == GPIO_PIN_SET)
            track_mode();
        else if(TRACK_PIN == GPIO_PIN_SET && FOLLOW_PIN == GPIO_PIN_RESET && AVOID_PIN == GPIO_PIN_SET)
            follow_mode();
        else if(TRACK_PIN == GPIO_PIN_SET && FOLLOW_PIN == GPIO_PIN_SET && AVOID_PIN == GPIO_PIN_RESET)
            avoid_mode();
    }
}

