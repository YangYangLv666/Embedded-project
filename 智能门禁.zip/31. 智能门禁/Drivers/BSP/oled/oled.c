#include "oled.h"
#include "delay.h"
#include "font.h"

void oled_gpio_init(void)
{
    GPIO_InitTypeDef gpio_initstruct;

    OLED_I2C_SCL_CLK();
    OLED_I2C_SDA_CLK();
    
    gpio_initstruct.Pin = OLED_I2C_SCL_PIN;          
    gpio_initstruct.Mode = GPIO_MODE_OUTPUT_PP;             
    gpio_initstruct.Pull = GPIO_PULLUP;                     
    gpio_initstruct.Speed = GPIO_SPEED_FREQ_HIGH;           
    HAL_GPIO_Init(OLED_I2C_SCL_PORT, &gpio_initstruct);
    
    gpio_initstruct.Pin = OLED_I2C_SDA_PIN;          
    HAL_GPIO_Init(OLED_I2C_SDA_PORT, &gpio_initstruct);
}

void oled_i2c_start(void)
{
    OLED_SCL_SET();
    OLED_SDA_SET();
    OLED_SDA_RESET();
    OLED_SCL_RESET();
}

void oled_i2c_stop(void)
{
    OLED_SCL_SET();
    OLED_SDA_RESET();
    OLED_SDA_SET();
}

void oled_i2c_ack(void)
{
    OLED_SCL_SET();
    OLED_SCL_RESET();
}

void oled_i2c_write_byte(uint8_t data)
{
    uint8_t i, tmp;
    tmp = data;
    
    for(i = 0; i < 8; i++)
    {
        if((tmp & 0x80) == 0x80)
            OLED_SDA_SET();
        else
            OLED_SDA_RESET();
        tmp = tmp << 1;
        OLED_SCL_SET();
        OLED_SCL_RESET();
    }
}

void oled_write_cmd(uint8_t cmd)
{
    oled_i2c_start();
    oled_i2c_write_byte(0x78);
    oled_i2c_ack();
    oled_i2c_write_byte(0x00);
    oled_i2c_ack();
    oled_i2c_write_byte(cmd);
    oled_i2c_ack();
    oled_i2c_stop();
}

void oled_write_data(uint8_t data)
{
    oled_i2c_start();
    oled_i2c_write_byte(0x78);
    oled_i2c_ack();
    oled_i2c_write_byte(0x40);
    oled_i2c_ack();
    oled_i2c_write_byte(data);
    oled_i2c_ack();
    oled_i2c_stop();
}

void oled_init(void)
{
    oled_gpio_init();
    
    delay_ms(100);
    
    oled_write_cmd(0xAE);    //������ʾ����/�رգ�0xAE�رգ�0xAF����

    oled_write_cmd(0xD5);    //������ʾʱ�ӷ�Ƶ��/����Ƶ��
    oled_write_cmd(0x80);    //0x00~0xFF

    oled_write_cmd(0xA8);    //���ö�·������
    oled_write_cmd(0x3F);    //0x0E~0x3F

    oled_write_cmd(0xD3);    //������ʾƫ��
    oled_write_cmd(0x00);    //0x00~0x7F

    oled_write_cmd(0x40);    //������ʾ��ʼ�У�0x40~0x7F

    oled_write_cmd(0xA1);    //�������ҷ���0xA1������0xA0���ҷ���

    oled_write_cmd(0xC8);    //�������·���0xC8������0xC0���·���

    oled_write_cmd(0xDA);    //����COM����Ӳ������
    oled_write_cmd(0x12);

    oled_write_cmd(0x81);    //���öԱȶ�
    oled_write_cmd(0xCF);    //0x00~0xFF

    oled_write_cmd(0xD9);    //����Ԥ�������
    oled_write_cmd(0xF1);

    oled_write_cmd(0xDB);    //����VCOMHȡ��ѡ�񼶱�
    oled_write_cmd(0x30);

    oled_write_cmd(0xA4);    //����������ʾ��/�ر�

    oled_write_cmd(0xA6);    //��������/��ɫ��ʾ��0xA6������0xA7��ɫ

    oled_write_cmd(0x8D);    //���ó���
    oled_write_cmd(0x14);

    oled_write_cmd(0xAF);    //������ʾ
    
    oled_fill(0x00);
}

void oled_set_cursor(uint8_t x, uint8_t y)
{
    oled_write_cmd(0xB0 + y);
    oled_write_cmd((x & 0x0F) | 0x00);
    oled_write_cmd(((x & 0xF0) >> 4) | 0x10);
}

void oled_fill(uint8_t data)
{
    uint8_t i, j;
    for(i = 0; i < 8; i++)
    {
        oled_set_cursor(0, i);
        for(j = 0; j < 128; j++)
            oled_write_data(data);
    }
}

void oled_show_char(uint8_t x, uint8_t y, uint8_t num, uint8_t size)
{
    uint8_t i, j, page;
    
    num = num - ' ';
    page = size / 8;
    if(size % 8)
        page++;
    
    for(j = 0; j < page; j++)
    {
        oled_set_cursor(x, y + j);
        for(i = size / 2 * j; i < size /2 * (j + 1); i++)
        {
            if(size == 12)
                oled_write_data(ascii_6X12[num][i]);
            else if(size == 16)
                oled_write_data(ascii_8X16[num][i]);
            else if(size == 24)
                oled_write_data(ascii_12X24[num][i]);
                
        }
    }
}

void oled_show_string(uint8_t x, uint8_t y, char *p, uint8_t size)
{
    while(*p != '\0')
    {
        oled_show_char(x, y, *p, size);
        x += size/2;
        p++;
    }
}

//void oled_show_chinese(uint8_t x, uint8_t y, uint8_t N, uint8_t size)
//{
//    uint16_t i, j;
//    for(j = 0; j < size/8; j++)
//    {
//        oled_set_cursor(x, y + j);
//        for(i = size *j; i < size * (j + 1); i++)
//        {
//            if(size == 16)
//                oled_write_data(chinese_16x16[N][i]);
//            else if(size == 24)
//                oled_write_data(chinese_24x24[N][i]);
//        }
//    }
//}

void oled_show_chinese(uint8_t x, uint8_t y, uint8_t N, uint8_t message_type)
{
    uint16_t i, j;
    for(j = 0; j < 2; j++)
    {
        oled_set_cursor(x, y + j);
        for(i = 16 * j; i < 16 * (j + 1); i++)
        {
            switch(message_type)
            {
                case SHOW_INPUT_PWD:
                    oled_write_data(chinese_enter_password[N][i]);
                    break;
                
                case SHOW_PWD_RIGHT:
                    oled_write_data(chinese_password_right[N][i]);
                    break;
                
                case SHOW_PWD_WRONG:
                    oled_write_data(chinese_password_wrong[N][i]);
                    break;
                
                case SHOW_INPUT_OLD_PWD:
                    oled_write_data(chinese_enter_old_password[N][i]);
                    break;
                
                case SHOW_INPUT_NEW_PWD:
                    oled_write_data(chinese_enter_new_password[N][i]);
                    break;
                
                case SHOW_PWD_CHANGED:
                    oled_write_data(chinese_password_changed[N][i]);
                    break;
                
                case SHOW_SET_PWD:
                    oled_write_data(chinese_set_password[N][i]);
                    break;
                
                default:
                    break;
            }
        }
    }
}

//����������
void oled_show_input(void)
{
    oled_fill(0x00);
    oled_show_chinese(10, 1, 0, SHOW_INPUT_PWD);
    oled_show_chinese(30, 1, 1, SHOW_INPUT_PWD);
    oled_show_chinese(50, 1, 2, SHOW_INPUT_PWD);
    oled_show_chinese(70, 1, 3, SHOW_INPUT_PWD);
    oled_show_chinese(90, 1, 4, SHOW_INPUT_PWD);
    oled_show_char(110, 1, ':', 16);
}

//������ȷ
void oled_show_right(void)
{
    oled_fill(0x00);
    oled_show_chinese(20,1,0,SHOW_PWD_RIGHT);
    oled_show_chinese(45,1,1,SHOW_PWD_RIGHT);
    oled_show_chinese(70,1,2,SHOW_PWD_RIGHT);
    oled_show_chinese(95,1,3,SHOW_PWD_RIGHT);
}

//�������
void oled_show_wrong(void)
{
    oled_fill(0x00);
    oled_show_chinese(20,1,0,SHOW_PWD_WRONG);
    oled_show_chinese(45,1,1,SHOW_PWD_WRONG);
    oled_show_chinese(70,1,2,SHOW_PWD_WRONG);
    oled_show_chinese(95,1,3,SHOW_PWD_WRONG);
}

//�����������
void oled_show_old(void)
{
    oled_fill(0x00);
    oled_show_chinese(10,1,0,SHOW_INPUT_OLD_PWD);
    oled_show_chinese(30,1,1,SHOW_INPUT_OLD_PWD);
    oled_show_chinese(50,1,2,SHOW_INPUT_OLD_PWD);
    oled_show_chinese(70,1,3,SHOW_INPUT_OLD_PWD);
    oled_show_chinese(90,1,4,SHOW_INPUT_OLD_PWD);
    oled_show_chinese(110,1,5,SHOW_INPUT_OLD_PWD);
}

//������������
void oled_show_new(void)
{
    oled_fill(0x00);
    oled_show_chinese(10,1,0,SHOW_INPUT_NEW_PWD);
    oled_show_chinese(30,1,1,SHOW_INPUT_NEW_PWD);
    oled_show_chinese(50,1,2,SHOW_INPUT_NEW_PWD);
    oled_show_chinese(70,1,3,SHOW_INPUT_NEW_PWD);
    oled_show_chinese(90,1,4,SHOW_INPUT_NEW_PWD);
    oled_show_chinese(110,1,5,SHOW_INPUT_NEW_PWD);
}

//�����޸ĳɹ�
void oled_show_set(void)
{
    oled_fill(0x00);
    oled_show_chinese(10,1,0,SHOW_SET_PWD);
    oled_show_chinese(30,1,1,SHOW_SET_PWD);
    oled_show_chinese(50,1,2,SHOW_SET_PWD);
    oled_show_chinese(70,1,3,SHOW_SET_PWD);
    oled_show_chinese(90,1,4,SHOW_SET_PWD);
    oled_show_char(110,1,':',16);
}

//���趨����
void oled_show_changed(void)
{
    oled_fill(0x00);
    oled_show_chinese(10,1,0,SHOW_PWD_CHANGED);
    oled_show_chinese(30,1,1,SHOW_PWD_CHANGED);
    oled_show_chinese(50,1,2,SHOW_PWD_CHANGED);
    oled_show_chinese(70,1,3,SHOW_PWD_CHANGED);
    oled_show_chinese(90,1,4,SHOW_PWD_CHANGED);
    oled_show_chinese(110,1,5,SHOW_PWD_CHANGED);
}

void oled_show_image(uint8_t x, uint8_t y, uint8_t width, uint8_t height, uint8_t *bmp)
{
    uint8_t i, j;
    for(j = 0; j < height; j++)
    {
        oled_set_cursor(x, y + j);
        for(i = 0; i < width; i++)
            oled_write_data(bmp[width * j + i]);
    }
}
