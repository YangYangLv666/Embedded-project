#include "sys.h"
#include "delay.h"
#include "led.h"
#include "uart1.h"
#include "FreeRTOS.h"
#include "freertos_test.h"
#include "task.h"
#include "beep.h"
#include "keyboard.h"
#include "lock.h"
#include "oled.h"
#include "password.h"

int main(void)
{
    HAL_Init();                         /* ��ʼ��HAL�� */
    stm32_clock_init(RCC_PLL_MUL9);     /* ����ʱ��, 72Mhz */
    delay_init();
    led_init();                         /* ��ʼ��LED�� */
    uart1_init(115200);
    printf("hello world!\r\n");
    
    beep_init();
    keyboard_init();
    lock_init();
    oled_init();
    password_init();

    freertos_test();
    vTaskStartScheduler();
}

