#ifndef __BEEP_H
#define __BEEP_H 

void fmq_Init(void);
void fmq(int temp,int humi);

#endif


